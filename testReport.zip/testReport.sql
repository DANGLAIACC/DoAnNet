﻿create database test2
go
use test2
go
create table genre(
	Id int primary key,
	Iname nvarchar(200),
	SortOrder int
)
go
insert into genre values
(1,'Rap and Hiphop',14),
(2,'Pop',12),
(3,'Jazz',8),
(4,'Hard Rock',3),
(5,'Indie Rock',1),
(6,'Punk',4),
(7,'Rock',2),
(8,'Grunge',5),
(9,'Alternative Rock',7),
(10,'Reggae',9)

