﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.Shared;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Windows.Forms;

namespace testReportListObject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            CrystalReport1 cr = new CrystalReport1();
            crystalReportViewer1.ReportSource = cr;

            cr.SetDataSource(GetStudentList());
        }
        List<Student> GetStudentList()
        {
            Student s1 = new Student("1000001", "Ashkan Power", DateTime.Parse("17/7/1989"));
            Student s2 = new Student("1000002", "Peter Griffin", DateTime.Parse("10/2/1960"));
            Student s3 = new Student("1000003", "Super Man", DateTime.Parse("1/1/1980"));
            Student s4 = new Student("1000004", "Jim Carry", DateTime.Parse("14/5/1985"));
            Student s5 = new Student("1000005", "Bill Carter", DateTime.Parse("25/8/1940"));

            return new List<Student>() { s1, s2, s3, s4, s5 };
        }
    }
}
