﻿namespace testReportListObject
{


    partial class MyDS
    {
    }
}
