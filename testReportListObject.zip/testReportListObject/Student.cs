﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testReportListObject
{
    class Student
    {
        public Student(string Code, string Name, DateTime BirthDate)
        {
            this.Code = Code;
            this.Name = Name;
            this.BirthDate = BirthDate;
        }

        public string Code { set; get; }
        public string Name { set; get; }
        public DateTime BirthDate { set; get; }
        public int Age
        {
            get
            {
                int now = DateTime.Now.Year;
                int birth = BirthDate.Year;

                return now - birth;
            }
        }
    }
}
